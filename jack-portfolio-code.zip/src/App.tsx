import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ContactSection } from './components/ContactSection';

function App() {
  return (
    <div className="w-full bg-[#0C0C0C] min-h-screen overflow-x-clip select-none">
      {/* 1. HERO SECTION */}
      <HeroSection />

      {/* 2. ABOUT SECTION */}
      <AboutSection />

      {/* 3. PROJECTS SECTION */}
      <ProjectsSection />

      {/* 4. CONTACT SECTION */}
      <ContactSection />
    </div>
  );
}

export default App;
