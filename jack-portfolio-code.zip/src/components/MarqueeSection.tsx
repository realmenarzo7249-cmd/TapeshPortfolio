import React, { useRef, useState, useEffect } from 'react';

interface MarqueeItem {
  type: 'video' | 'image';
  url: string;
}

const row1Items: MarqueeItem[] = [
  { type: 'video', url: '/videos/harsh Trading.mp4' },
  { type: 'image', url: 'https://motionsites.ai/assets/hero-space-voyage-preview-eECLH3Yc.gif' },
  { type: 'video', url: '/videos/Orchids without logo.mp4' },
  { type: 'image', url: 'https://motionsites.ai/assets/hero-vex-ventures-preview-BczMFIiw.gif' },
  { type: 'video', url: '/videos/Vidyadoot Without logo.mp4' },
  { type: 'image', url: 'https://motionsites.ai/assets/hero-asme-preview-B_nGDnTP.gif' },
];

const row2Items: MarqueeItem[] = [
  { type: 'video', url: '/videos/Patil Trading.mp4' },
  { type: 'image', url: 'https://motionsites.ai/assets/hero-stellar-ai-preview-D3HL6bw1.gif' },
  { type: 'video', url: '/videos/Before After.mp4' },
  { type: 'image', url: 'https://motionsites.ai/assets/hero-xportfolio-preview-D4A8maiC.gif' },
  { type: 'video', url: '/videos/IINSIGHT Without logo.mp4' },
  { type: 'image', url: 'https://motionsites.ai/assets/hero-orbit-web3-preview-BXt4OttD.gif' },
];

export const MarqueeSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const sectionTop = rect.top + window.scrollY;
      const calculatedOffset = (window.scrollY - sectionTop + window.innerHeight) * 0.3;
      setOffset(calculatedOffset);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Initialize on mount

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Triple the arrays to ensure a continuous and seamless horizontal scrolling stream
  const tripledRow1 = [...row1Items, ...row1Items, ...row1Items];
  const tripledRow2 = [...row2Items, ...row2Items, ...row2Items];

  return (
    <section
      ref={sectionRef}
      className="bg-[#0C0C0C] pt-24 sm:pt-32 md:pt-40 pb-10 overflow-hidden w-full flex flex-col gap-3"
    >
      {/* Row 1: Moves RIGHT on scroll (translateX(offset - 200)) */}
      <div className="w-full overflow-hidden">
        <div
          style={{
            transform: `translateX(${offset - 200}px)`,
            willChange: 'transform',
          }}
          className="flex flex-row flex-nowrap whitespace-nowrap gap-3 transition-transform duration-75 ease-out"
        >
          {tripledRow1.map((item, i) => (
            item.type === 'video' ? (
              <video
                key={`row1-video-${i}`}
                src={item.url}
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-[420px] h-[270px] rounded-2xl object-cover flex-shrink-0 select-none border border-[#D7E2EA]/10"
              />
            ) : (
              <img
                key={`row1-img-${i}`}
                src={item.url}
                alt={`Project preview image ${i + 1}`}
                className="w-[420px] h-[270px] rounded-2xl object-cover flex-shrink-0 select-none border border-[#D7E2EA]/10"
                loading="lazy"
              />
            )
          ))}
        </div>
      </div>

      {/* Row 2: Moves LEFT on scroll (translateX(-(offset - 200))) */}
      <div className="w-full overflow-hidden">
        <div
          style={{
            transform: `translateX(${-(offset - 200)}px)`,
            willChange: 'transform',
          }}
          className="flex flex-row flex-nowrap whitespace-nowrap gap-3 transition-transform duration-75 ease-out"
        >
          {tripledRow2.map((item, i) => (
            item.type === 'video' ? (
              <video
                key={`row2-video-${i}`}
                src={item.url}
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-[420px] h-[270px] rounded-2xl object-cover flex-shrink-0 select-none border border-[#D7E2EA]/10"
              />
            ) : (
              <img
                key={`row2-img-${i}`}
                src={item.url}
                alt={`Project preview image ${i + 1}`}
                className="w-[420px] h-[270px] rounded-2xl object-cover flex-shrink-0 select-none border border-[#D7E2EA]/10"
                loading="lazy"
              />
            )
          ))}
        </div>
      </div>
    </section>
  );
};
