import React from 'react';
import { Navbar } from './Navbar';
import { ContactButton } from './ContactButton';
import { Magnet } from './Magnet';
import { FadeIn } from './FadeIn';

export const HeroSection: React.FC = () => {
  const portraitUrl = '/tapesh_suit_avatar.png';

  const handleContactClick = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative h-screen w-full flex flex-col justify-between overflow-hidden bg-[#0C0C0C]">
      {/* Top Navbar */}
      <FadeIn delay={0} y={-20}>
        <Navbar />
      </FadeIn>

      {/* Hero Portrait - Bottom-aligned with 3D Holographic Orbit Layers */}
      <FadeIn
        delay={0.6}
        y={30}
        className="absolute left-1/2 -translate-x-1/2 z-20 w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px] top-1/2 -translate-y-1/2 sm:top-auto sm:translate-y-0 sm:bottom-0 pointer-events-none flex justify-center items-end"
      >
        <Magnet
          padding={150}
          strength={3}
          activeTransition="transform 0.3s ease-out"
          inactiveTransition="transform 0.6s ease-in-out"
          className="pointer-events-auto select-none flex items-center justify-center relative w-full"
        >
          {/* Volumetric Radial Aura / Glow */}
          <div
            style={{
              background: 'radial-gradient(circle, rgba(190,76,0,0.18) 0%, rgba(24,1,31,0.4) 60%, transparent 100%)',
              transform: 'translateZ(-30px)',
            }}
            className="absolute w-[120%] h-[120%] rounded-full opacity-40 blur-3xl pointer-events-none z-0 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          />

          {/* 3D Planetary Ring 1 (Tilted dashed line, slow spin) */}
          <div
            style={{
              transform: 'rotateX(75deg) rotateY(-15deg) translateZ(-15px)',
              transformStyle: 'preserve-3d',
            }}
            className="absolute -inset-4 sm:-inset-6 md:-inset-8 rounded-full border border-dashed border-[#D7E2EA]/20 animate-[spin_40s_linear_infinite] z-0 pointer-events-none"
          />

          {/* 3D Planetary Ring 2 (Tilted double line, reverse slow spin) */}
          <div
            style={{
              transform: 'rotateX(65deg) rotateY(30deg) translateZ(-25px)',
              transformStyle: 'preserve-3d',
            }}
            className="absolute -inset-10 sm:-inset-14 md:-inset-18 rounded-full border border-double border-[#D7E2EA]/15 animate-[spin_30s_linear_infinite_reverse] z-0 pointer-events-none"
          />

          {/* Foreground Character Portrait (Pops forward in Z-space) */}
          <img
            src={portraitUrl}
            alt="Tapesh Portrait"
            style={{
              transform: 'translateZ(20px)',
            }}
            className="w-full h-auto object-contain relative z-10 block"
            draggable="false"
          />
        </Magnet>
      </FadeIn>

      {/* Hero Heading - Centered in middle */}
      <div className="flex-grow flex items-center justify-center relative z-10 pointer-events-none">
        <div className="w-full overflow-hidden text-center px-4">
          <FadeIn delay={0.15} y={40}>
            <h1 className="hero-heading font-black uppercase tracking-tight leading-none whitespace-nowrap w-full text-[10vw] sm:text-[11vw] md:text-[12vw] lg:text-[13vw] mt-6 sm:mt-4 md:-mt-5">
              hi, i&apos;m tapesh
            </h1>
          </FadeIn>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="relative z-30 flex justify-between items-end w-full px-6 md:px-10 pb-7 sm:pb-8 md:pb-10 pointer-events-none">
        {/* Left Sub-description */}
        <FadeIn delay={0.35} y={20} className="pointer-events-auto">
          <p
            className="text-[#D7E2EA] font-light uppercase tracking-wide leading-snug max-w-[160px] sm:max-w-[220px] md:max-w-[260px] text-left"
            style={{ fontSize: 'clamp(0.75rem, 1.4vw, 1.5rem)' }}
          >
            A Video Editor driven by crafting striking and unforgettable projects
          </p>
        </FadeIn>

        {/* Right Button */}
        <FadeIn delay={0.5} y={20} className="pointer-events-auto">
          <ContactButton onClick={handleContactClick} />
        </FadeIn>
      </div>
    </section>
  );
};
