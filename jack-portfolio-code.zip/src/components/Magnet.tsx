import React, { useRef, useState, useEffect } from 'react';

interface MagnetProps {
  children: React.ReactNode;
  strength?: number;
  padding?: number;
  activeTransition?: string;
  inactiveTransition?: string;
  className?: string;
}

export const Magnet: React.FC<MagnetProps> = ({
  children,
  strength = 3,
  padding = 150,
  activeTransition = 'transform 0.3s ease-out',
  inactiveTransition = 'transform 0.6s ease-in-out',
  className = '',
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0 });
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const distanceX = e.clientX - centerX;
      const distanceY = e.clientY - centerY;
      
      const distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY);
      
      // Calculate trigger boundary (half of the largest dimension + activation padding)
      const triggerBoundary = Math.max(rect.width, rect.height) / 2 + padding;

      if (distance < triggerBoundary) {
        setIsHovered(true);
        // Translate divided by the strength factor (closer to cursor)
        const targetX = distanceX / strength;
        const targetY = distanceY / strength;
        setTransform({ x: targetX, y: targetY });

        // Calculate 3D tilt percentage relative to boundary (max 15 degrees rotation)
        const pctX = distanceX / triggerBoundary;
        const pctY = distanceY / triggerBoundary;
        const tiltX = -pctY * 15; // vertical offset rotates along X-axis
        const tiltY = pctX * 15;  // horizontal offset rotates along Y-axis
        setRotation({ x: tiltX, y: tiltY });
      } else {
        setIsHovered(false);
        setTransform({ x: 0, y: 0 });
        setRotation({ x: 0, y: 0 });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [strength, padding]);

  return (
    <div
      ref={ref}
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
      className="inline-block relative"
    >
      <div
        style={{
          transform: `translate3d(${transform.x}px, ${transform.y}px, 0) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
          transition: isHovered ? activeTransition : inactiveTransition,
          willChange: 'transform',
          transformStyle: 'preserve-3d',
        }}
        className={`w-full h-full ${className}`}
      >
        {children}
      </div>
    </div>
  );
};
