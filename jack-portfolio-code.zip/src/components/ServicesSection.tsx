import React from 'react';
import { FadeIn } from './FadeIn';

interface ServiceItem {
  number: string;
  name: string;
  description: string;
}

export const ServicesSection: React.FC = () => {
  const services: ServiceItem[] = [
    {
      number: '01',
      name: '3D Modeling',
      description:
        'Creation of detailed objects, characters, or environments tailored to specific client needs, ideal for games, products, and visualizations.',
    },
    {
      number: '02',
      name: 'Rendering',
      description:
        'High-quality, photorealistic renders that showcase designs with custom lighting, textures, and materials to bring concepts to life.',
    },
    {
      number: '03',
      name: 'Motion Design',
      description:
        'Dynamic animations and motion graphics that add energy and storytelling to brands, products, and digital experiences.',
    },
    {
      number: '04',
      name: 'Branding',
      description:
        'Crafting cohesive visual identities -- from logos to full brand systems -- that communicate a clear and memorable presence.',
    },
    {
      number: '05',
      name: 'Web Design',
      description:
        'Designing clean, modern, and conversion-focused websites with attention to layout, typography, and user experience.',
    },
  ];

  return (
    <section
      id="services"
      className="bg-white rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32 w-full text-center relative z-20"
    >
      {/* Services Heading */}
      <FadeIn delay={0} y={40} className="w-full text-center mb-16 sm:mb-20 md:mb-28">
        <h2
          className="text-[#0C0C0C] font-black uppercase leading-none tracking-tight text-center"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Services
        </h2>
      </FadeIn>

      {/* Services List */}
      <div className="max-w-5xl mx-auto flex flex-col w-full">
        {services.map((service, index) => (
          <FadeIn
            key={service.number}
            delay={index * 0.1}
            y={30}
            className="w-full"
          >
            <div className="flex flex-row items-center border-t border-[rgba(12,12,12,0.15)] last:border-b py-8 sm:py-10 md:py-12 w-full">
              {/* Service Number */}
              <span
                className="font-black leading-none mr-6 sm:mr-10 md:mr-16 text-[#0C0C0C] select-none text-left min-w-[2.5ch]"
                style={{ fontSize: 'clamp(3rem, 10vw, 140px)' }}
              >
                {service.number}
              </span>

              {/* Service Details */}
              <div className="flex flex-col text-left justify-center flex-grow">
                <h3
                  className="font-medium uppercase mb-2 sm:mb-3 text-[#0C0C0C] leading-snug"
                  style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)' }}
                >
                  {service.name}
                </h3>
                <p
                  className="font-light leading-relaxed max-w-2xl text-[#0C0C0C] opacity-60"
                  style={{ fontSize: 'clamp(0.85rem, 1.6vw, 1.25rem)' }}
                >
                  {service.description}
                </p>
              </div>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>
  );
};
