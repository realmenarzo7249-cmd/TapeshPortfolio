import React, { useRef, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FadeIn } from './FadeIn';
import { Volume2, VolumeX, Play, Pause } from 'lucide-react';

interface ProjectData {
  number: string;
  category: string;
  name: string;
  videoPath: string;
  tools: string[];
  description: string;
}

const projects: ProjectData[] = [
  {
    number: '01',
    category: 'Commercial Promo',
    name: 'Harsh Trading Promotion',
    videoPath: '/videos/harsh Trading.mp4',
    tools: ['After Effects', 'Premiere Pro', 'Sound Mix', 'Color Grading'],
    description: 'A dynamic, high-energy promotional edit for Harsh Trading. Engineered with sync beats, cinematic color grading, and modern motion typography to maximize audience engagement.',
  },
  {
    number: '02',
    category: 'Brand Showcase',
    name: 'Patil Trading Commercial',
    videoPath: '/videos/Patil Trading.mp4',
    tools: ['VFX Compositing', 'Dynamic Cutting', 'Premiere Pro', 'Visual Identity'],
    description: 'A premium corporate showcase highlighting business operations and scale. Leverages clean transitions, professional sound design, and elegant text layers.',
  },
  {
    number: '03',
    category: 'Institutional Branding',
    name: 'Orchids School Campaign',
    videoPath: '/videos/Orchids without logo.mp4',
    tools: ['Commercial Editing', 'Luminance Tuning', 'After Effects', 'Storytelling'],
    description: 'An engaging, cinematic corporate edit highlighting advanced learning spaces, student development, and modern campus life with rich warm color tones.',
  },
  {
    number: '04',
    category: 'VFX & Post-Production',
    name: 'Before After Reel',
    videoPath: '/videos/Before After.mp4',
    tools: ['Before/After VFX', 'Visual Matchmoving', 'After Effects', 'Grading'],
    description: 'A professional technical reel demonstrating the transformation of raw logarithmic camera files into fully composite-graded visual masterworks.',
  },
  {
    number: '05',
    category: 'Corporate Identity',
    name: 'Vidyadoot Campaign',
    videoPath: '/videos/Vidyadoot Without logo.mp4',
    tools: ['Motion Graphics', 'Sound Editing', 'Premiere Pro', 'Audio Sync'],
    description: 'An impactful corporate campaign film explaining digital innovation and learning services. Features advanced tracking elements and clean audio arrangements.',
  },
  {
    number: '06',
    category: 'Cinematic Reel',
    name: 'IINSIGHT Promotion',
    videoPath: '/videos/IINSIGHT Without logo.mp4',
    tools: ['Cinematic Editing', 'Audio Mix', 'VFX Overlay', 'After Effects'],
    description: 'A futuristic, high-concept visual commercial created to showcase digital insight services. Styled with immersive low-frequency soundscapes and atmospheric grading.',
  },
];

export const ProjectsSection: React.FC = () => {
  return (
    <section
      id="projects"
      className="bg-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] -mt-10 sm:-mt-12 md:-mt-14 z-30 pt-20 sm:pt-24 md:pt-32 pb-24 md:pb-32 px-5 sm:px-8 md:px-10 w-full relative"
    >
      {/* Project Section Heading */}
      <FadeIn delay={0} y={40} className="w-full text-center mb-16 sm:mb-20 md:mb-28">
        <h2
          className="hero-heading font-black uppercase leading-none tracking-tight text-center"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Projects
        </h2>
      </FadeIn>

      {/* 2-Column Responsive Grid */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-12 md:gap-16 w-full relative">
        {projects.map((project, index) => (
          <ProjectCard
            key={project.number}
            index={index}
            project={project}
          />
        ))}
      </div>
    </section>
  );
};

interface ProjectCardProps {
  index: number;
  project: ProjectData;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ index, project }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  // Handle Play/Pause toggle
  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  // Handle Mute/Unmute toggle
  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handlePlayStatus = () => setIsPlaying(true);
    const handlePauseStatus = () => setIsPlaying(false);

    video.addEventListener('play', handlePlayStatus);
    video.addEventListener('pause', handlePauseStatus);

    return () => {
      video.removeEventListener('play', handlePlayStatus);
      video.removeEventListener('pause', handlePauseStatus);
    };
  }, []);

  return (
    <FadeIn delay={index % 2 * 0.15} y={40} className="w-full">
      <div
        className="w-full flex flex-col gap-5 bg-[#0C0C0C] border-2 border-[#D7E2EA]/10 rounded-[35px] sm:rounded-[45px] p-4 sm:p-5 hover:border-[#D7E2EA]/30 transition-all duration-500 shadow-2xl relative group cursor-pointer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={togglePlay}
      >
        {/* Aspect 9:16 Video Player Container */}
        <div className="w-full aspect-[9/16] rounded-[25px] sm:rounded-[35px] overflow-hidden border border-[#D7E2EA]/10 bg-black relative flex items-center justify-center">
          <motion.video
            ref={videoRef}
            src={project.videoPath}
            autoPlay
            loop
            muted={isMuted}
            playsInline
            preload="auto"
            animate={{ scale: isHovered ? 1.03 : 1 }}
            transition={{ duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
            className="w-full h-full object-cover select-none pointer-events-none"
          />

          {/* Glassmorphic Play/Pause Overlay Indicator on Hover */}
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: isHovered ? 1 : 0.8, opacity: isHovered ? 1 : 0 }}
              className="w-14 h-14 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-lg"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 text-[#D7E2EA] fill-current" />
              ) : (
                <Play className="w-6 h-6 text-[#D7E2EA] fill-current translate-x-0.5" />
              )}
            </motion.div>
          </div>

          {/* Mute/Unmute Floating Glassmorphic Pill */}
          <button
            onClick={toggleMute}
            className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-black/40 backdrop-blur-md border border-[#D7E2EA]/10 text-[#D7E2EA] hover:bg-white hover:text-black hover:scale-105 active:scale-95 transition-all duration-300 shadow-xl"
            title={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>

          {/* Floating Index Number */}
          <span className="absolute bottom-4 left-5 z-10 font-black text-[#D7E2EA] opacity-35 select-none text-4xl sm:text-5xl tracking-tighter">
            {project.number}
          </span>
        </div>

        {/* Text Information below the video */}
        <div className="flex flex-col gap-3 px-2 sm:px-3">
          {/* Header row: Title and Category */}
          <div className="flex flex-col gap-1">
            <span className="text-[#D7E2EA]/50 uppercase tracking-widest text-[9px] sm:text-[10px] font-light">
              {project.category}
            </span>
            <h3 className="text-[#D7E2EA] font-semibold uppercase text-lg sm:text-xl md:text-2xl leading-snug whitespace-nowrap overflow-hidden text-ellipsis">
              {project.name}
            </h3>
          </div>

          {/* Description */}
          <p className="text-[#D7E2EA]/70 text-xs sm:text-sm font-light leading-relaxed">
            {project.description}
          </p>

          {/* Tech stack tags */}
          <div className="flex flex-wrap gap-1.5 sm:gap-2 pt-2">
            {project.tools.map((tool) => (
              <span
                key={tool}
                className="px-2.5 py-1 text-[9px] sm:text-[10px] font-medium uppercase tracking-wider text-[#D7E2EA] rounded-full border border-[#D7E2EA]/20 bg-[#D7E2EA]/5 hover:bg-[#D7E2EA]/10 hover:border-[#D7E2EA]/40 transition-all duration-300"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>
      </div>
    </FadeIn>
  );
};
