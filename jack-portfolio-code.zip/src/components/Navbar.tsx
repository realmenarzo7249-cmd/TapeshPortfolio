import React from 'react';

export const Navbar: React.FC = () => {
  const links = [
    { label: 'About', href: '#about' },
    { label: 'Projects', href: '#projects' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="flex justify-between items-center w-full px-6 md:px-10 pt-6 md:pt-8 z-50">
      {links.map((link) => (
        <a
          key={link.label}
          href={link.href}
          onClick={(e) => handleScroll(e, link.href)}
          className="text-[#D7E2EA] font-medium uppercase tracking-wider text-sm md:text-lg lg:text-[1.4rem] transition-opacity duration-200 hover:opacity-70 cursor-pointer"
        >
          {link.label}
        </a>
      ))}
    </nav>
  );
};
