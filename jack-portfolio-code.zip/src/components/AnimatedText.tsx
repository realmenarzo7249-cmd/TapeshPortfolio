import React, { useRef } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion';

interface AnimatedTextProps {
  text: string;
  className?: string;
  style?: React.CSSProperties;
}

export const AnimatedText: React.FC<AnimatedTextProps> = ({ text, className = '', style }) => {
  const ref = useRef<HTMLParagraphElement>(null);
  
  // 1. Get scroll progress targeting the paragraph element
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start 0.8', 'end 0.2'],
  });

  // Split text into characters
  const chars = text.split('');

  return (
    <p ref={ref} style={style} className={`relative flex flex-wrap justify-center ${className}`}>
      {chars.map((char, index) => {
        // Calculate range for this character so they reveal sequentially
        const start = index / chars.length;
        const end = (index + 1) / chars.length;
        
        return (
          <Character 
            key={index} 
            char={char} 
            progress={scrollYProgress} 
            range={[start, end]} 
          />
        );
      })}
    </p>
  );
};

interface CharacterProps {
  char: string;
  progress: MotionValue<number>;
  range: [number, number];
}

const Character: React.FC<CharacterProps> = ({ char, progress, range }) => {
  // Map the scroll progress of this character's window to opacity 0.2 to 1
  const opacity = useTransform(progress, range, [0.2, 1]);

  if (char === ' ') {
    return <span className="inline-block">&nbsp;</span>;
  }

  return (
    <span className="relative inline-block select-none">
      {/* Invisible placeholder for spacing */}
      <span className="opacity-0">{char}</span>
      {/* Absolute positioned animated span */}
      <motion.span 
        style={{ opacity }} 
        className="absolute top-0 left-0"
      >
        {char}
      </motion.span>
    </span>
  );
};
