import React from 'react';
import { FadeIn } from './FadeIn';

export const AboutSection: React.FC = () => {
  const cards = [
    {
      title: "I'm based in",
      content: "Nagpur, Maharashtra, India (Open to remote work)"
    },
    {
      title: "I worked at",
      content: [
        "Fishtech Solutions Pvt. Ltd. (Video Editor)",
        "Freelance & Client-Based Creative Projects"
      ]
    },
    {
      title: "My roles were",
      content: "Video Editor, Social Media Management"
    }
  ];

  return (
    <section
      id="about"
      className="relative min-h-screen bg-[#0C0C0C] px-6 sm:px-10 md:px-16 lg:px-24 py-20 sm:py-28 md:py-36 flex flex-col justify-center overflow-hidden w-full select-none"
    >
      {/* Ambient Radial background glows */}
      <div
        className="absolute top-1/4 left-1/12 w-[350px] h-[350px] rounded-full blur-3xl opacity-20 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(52,211,153,0.15) 0%, transparent 70%)',
        }}
      />
      <div
        className="absolute bottom-1/4 right-1/12 w-[400px] h-[400px] rounded-full blur-3xl opacity-15 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(99,102,241,0.1) 0%, transparent 70%)',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column - Heading */}
        <div className="lg:col-span-6 flex flex-col justify-center z-20">
          <FadeIn delay={0.1} x={-40} y={0} duration={0.8}>
            <h2
              className="font-black uppercase tracking-tight leading-[0.9] text-left"
              style={{
                fontSize: 'clamp(2.5rem, 6.5vw, 5.5rem)',
                fontFamily: "'Kanit', sans-serif",
              }}
            >
              <span className="text-white">A Quick</span>
              <br />
              <span
                style={{
                  background: 'linear-gradient(135deg, #34D399 0%, #10B981 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  color: 'transparent',
                }}
              >
                Background
              </span>
            </h2>
          </FadeIn>
        </div>

        {/* Right Column - Cards List */}
        <div className="lg:col-span-6 flex flex-col gap-6 sm:gap-8 w-full">
          {cards.map((card, index) => (
            <FadeIn
              key={index}
              delay={0.2 + index * 0.15}
              x={40}
              y={0}
              duration={0.8}
            >
              <div
                className="group relative backdrop-blur-md bg-[#18191E]/60 border border-white/10 hover:border-[#34D399]/30 hover:shadow-[0_15px_40px_rgba(52,211,153,0.05)] rounded-2xl sm:rounded-3xl p-6 sm:p-8 flex flex-col gap-3 transition-all duration-300 hover:-translate-y-1"
              >
                {/* Neon green glow indicator inside card */}
                <div className="absolute top-0 left-0 w-1.5 h-0 group-hover:h-full bg-gradient-to-b from-[#34D399] to-[#10B981] rounded-l-2xl sm:rounded-l-3xl transition-all duration-300" />
                
                {/* Title (Sentence-case, clean and bold) */}
                <span className="text-[#34D399] font-bold tracking-wider text-sm sm:text-base md:text-lg leading-none">
                  {card.title}
                </span>

                {/* Content (Highly readable, font-semibold, off-white for eye comfort) */}
                <div className="flex flex-col gap-2">
                  {Array.isArray(card.content) ? (
                    card.content.map((item, idx) => (
                      <p
                        key={idx}
                        className="text-[#E2E8F0] font-semibold tracking-wide leading-relaxed"
                        style={{ fontSize: 'clamp(0.95rem, 2vw, 1.25rem)' }}
                      >
                        {item}
                      </p>
                    ))
                  ) : (
                    <p
                      className="text-[#E2E8F0] font-semibold tracking-wide leading-relaxed"
                      style={{ fontSize: 'clamp(0.95rem, 2vw, 1.25rem)' }}
                    >
                      {card.content}
                    </p>
                  )}
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};
