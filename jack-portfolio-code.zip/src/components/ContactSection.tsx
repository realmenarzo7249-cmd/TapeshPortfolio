import React, { useState } from 'react';
import { Mail, ArrowUp, Copy, Check, Instagram, ExternalLink } from 'lucide-react';
import { FadeIn } from './FadeIn';

const WhatsAppIcon: React.FC = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current text-[#D7E2EA]/75 group-hover:text-white transition-colors">
    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.717-1.458L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.625 1.451 5.437 0 9.862-4.414 9.865-9.864.001-2.639-1.026-5.122-2.892-6.991-1.866-1.867-4.35-2.893-6.99-2.893-5.442 0-9.87 4.417-9.873 9.869-.001 1.777.472 3.511 1.371 5.042L1.71 21.082l5.12-1.342h-.183zm10.74-6.495c-.29-.145-1.72-.848-1.986-.944-.265-.096-.458-.145-.65.145-.192.29-.745.944-.913 1.135-.168.19-.336.213-.627.069-.29-.145-1.226-.452-2.334-1.44-.863-.77-1.446-1.72-1.615-2.012-.17-.29-.018-.448.127-.592.13-.13.29-.337.436-.505.145-.169.193-.289.29-.482.096-.193.048-.361-.024-.505-.072-.145-.65-1.56-.89-2.14-.236-.566-.475-.487-.65-.496-.17-.008-.362-.01-.553-.01-.193 0-.506.072-.77.361-.266.29-1.013.99-1.013 2.415 0 1.423 1.037 2.795 1.18 2.99.145.192 2.04 3.115 4.94 4.373.688.298 1.226.476 1.646.609.693.22 1.324.19 1.822.115.554-.083 1.72-.702 1.962-1.381.242-.678.242-1.258.17-1.38-.072-.124-.266-.193-.556-.338z" />
  </svg>
);

export const ContactSection: React.FC = () => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const email = 'tapeshmeshram7@gmail.com';
  const phone = '9860102204';
  const displayPhone = '+91 98601 02204';
  const instagram = 'tapesh.in';

  const copyEmail = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section
      id="contact"
      className="bg-[#0C0C0C] py-24 sm:py-32 px-5 sm:px-8 md:px-10 border-t border-[#D7E2EA]/10 relative z-30 w-full flex flex-col justify-center items-center text-center overflow-hidden"
    >
      <div className="max-w-5xl mx-auto flex flex-col items-center w-full">
        {/* Contact Title */}
        <FadeIn delay={0} y={30} className="mb-8">
          <h2
            className="hero-heading font-black uppercase leading-none tracking-tight"
            style={{ fontSize: 'clamp(2.5rem, 8vw, 100px)' }}
          >
            LET&apos;S CONNECT
          </h2>
        </FadeIn>

        {/* 3 Premium Contact Pills Row */}
        <FadeIn delay={0.1} y={20} className="w-full flex flex-col lg:flex-row items-stretch justify-center gap-4 sm:gap-6 mb-16 max-w-4xl">
          {/* Email Pill */}
          <div
            onClick={copyEmail}
            className="flex items-center gap-3 bg-[#D7E2EA]/5 hover:bg-[#D7E2EA]/10 border border-[#D7E2EA]/15 rounded-full px-6 py-4 transition-all duration-300 cursor-pointer group hover:-translate-y-0.5 active:translate-y-0 shadow-lg flex-1 justify-between"
          >
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-[#D7E2EA]/75 group-hover:text-white transition-colors" />
              <span className="text-[#D7E2EA] font-medium tracking-wide text-xs sm:text-sm">
                {email}
              </span>
            </div>
            <div className="pl-3 border-l border-[#D7E2EA]/20 ml-2">
              {copiedEmail ? (
                <Check className="w-4 h-4 text-green-400 animate-scale" />
              ) : (
                <Copy className="w-4 h-4 text-[#D7E2EA]/50 group-hover:text-white transition-colors" />
              )}
            </div>
          </div>

          {/* WhatsApp Pill */}
          <a
            href={`https://wa.me/91${phone}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 bg-[#D7E2EA]/5 hover:bg-[#D7E2EA]/10 border border-[#D7E2EA]/15 rounded-full px-6 py-4 transition-all duration-300 cursor-pointer group hover:-translate-y-0.5 active:translate-y-0 shadow-lg flex-1 justify-between"
          >
            <div className="flex items-center gap-3">
              <WhatsAppIcon />
              <span className="text-[#D7E2EA] font-medium tracking-wide text-xs sm:text-sm">
                {displayPhone}
              </span>
            </div>
            <div className="pl-3 border-l border-[#D7E2EA]/20 ml-2">
              <ExternalLink className="w-4 h-4 text-[#D7E2EA]/50 group-hover:text-white transition-colors" />
            </div>
          </a>

          {/* Instagram Pill */}
          <a
            href={`https://instagram.com/${instagram}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 bg-[#D7E2EA]/5 hover:bg-[#D7E2EA]/10 border border-[#D7E2EA]/15 rounded-full px-6 py-4 transition-all duration-300 cursor-pointer group hover:-translate-y-0.5 active:translate-y-0 shadow-lg flex-1 justify-between"
          >
            <div className="flex items-center gap-3">
              <Instagram className="w-5 h-5 text-[#D7E2EA]/75 group-hover:text-white transition-colors" />
              <span className="text-[#D7E2EA] font-medium tracking-wide text-xs sm:text-sm">
                @{instagram}
              </span>
            </div>
            <div className="pl-3 border-l border-[#D7E2EA]/20 ml-2">
              <ExternalLink className="w-4 h-4 text-[#D7E2EA]/50 group-hover:text-white transition-colors" />
            </div>
          </a>
        </FadeIn>

        {/* Minimal Social Buttons Row */}
        <FadeIn delay={0.2} y={20} className="flex gap-6 mb-16">
          <a
            href={`https://wa.me/91${phone}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 bg-[#D7E2EA]/5 rounded-full hover:bg-[#D7E2EA]/15 transition-all text-[#D7E2EA] hover:scale-110 active:scale-95 cursor-pointer group"
          >
            <WhatsAppIcon />
          </a>
          <a
            href={`https://instagram.com/${instagram}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 bg-[#D7E2EA]/5 rounded-full hover:bg-[#D7E2EA]/15 transition-all text-[#D7E2EA] hover:scale-110 active:scale-95 cursor-pointer"
          >
            <Instagram className="w-5 h-5" />
          </a>
          <a
            href={`mailto:${email}`}
            className="p-3.5 bg-[#D7E2EA]/5 rounded-full hover:bg-[#D7E2EA]/15 transition-all text-[#D7E2EA] hover:scale-110 active:scale-95 cursor-pointer"
          >
            <Mail className="w-5 h-5" />
          </a>
        </FadeIn>

        {/* Footer bottom elements */}
        <div className="flex flex-col sm:flex-row justify-between items-center w-full pt-10 border-t border-[#D7E2EA]/10 gap-6">
          <p className="text-[#D7E2EA]/40 text-xs sm:text-sm font-light uppercase tracking-wider">
            &copy; {new Date().getFullYear()} TAPESH. ALL RIGHTS RESERVED.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-[#D7E2EA]/60 hover:text-white font-medium uppercase tracking-widest text-xs transition-colors cursor-pointer"
          >
            Back to Top
            <div className="p-2 bg-[#D7E2EA]/10 rounded-full">
              <ArrowUp className="w-4 h-4" />
            </div>
          </button>
        </div>
      </div>
    </section>
  );
};
